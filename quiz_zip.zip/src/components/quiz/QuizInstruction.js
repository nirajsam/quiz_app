import React, {Component, Fragment} from 'react'
import { Helmet } from 'react-helmet'
import { Link } from 'react-router-dom'

const QuizInstructions = () => (
    <Fragment>
        <Helmet><title>Quiz-Instructions-Quiz App</title></Helmet>
        <div className="instructions container">
            <h2>How To play the Game</h2>
            <p>Ensure you read guidelines properly:</p>
            <ul className="browser-default" id="min-list">
                <li>Each Question consist of four answer</li>
            </ul><br></br><br></br>
            <div>
                <span className="left"><Link to="/">No take me back</Link></span>
                <span className="right"><Link to="/play/quiz">okay, lets do this</Link></span>
            </div>
        </div>
    </Fragment>
)
export default QuizInstructions;
