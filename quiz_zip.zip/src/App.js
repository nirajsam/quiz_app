import React from 'react';
import {BrowserRouter as Router, Route} from 'react-router-dom';
import Home from './components/Home';
import QuizInstructions from './components/quiz/QuizInstruction';
import play from './components/quiz/play';
import quizSummary from './components/quiz/quizSummary'

function App() {
  return (
    <Router>
      <Route path="/" exact component={Home}/>
      <Route  path="/play/instructions" exact component={QuizInstructions} />
      <Route  path="/play/quiz" exact component={play} />
      <Route  path="/play/quizSummary" exact component={quizSummary} />
    </Router>
  );
}

export default App;
